module Climbing
  
  def climb
    puts "This #{self.class.name} can climb"
  end
end
