module Naming
  attr_accessor :name
end
