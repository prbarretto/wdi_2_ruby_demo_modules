module Biting
  def bite
    puts "This #{self.class.name} with a name of #{name} can bite"
  end
end
