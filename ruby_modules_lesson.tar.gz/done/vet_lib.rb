module VetLib
  class Animal
    def self.visit_cost
      40
    end
  end

  class Monkey < Animal
    def self.visit_cost
      87
    end
  end

  class Dog < Animal
    def self.visit_cost
      10
    end
  end
end
