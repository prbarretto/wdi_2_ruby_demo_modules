## Modules & Mixins (1:00 - 1:30)

**Objectives:**
* Articulate the value of using modules in programming
* Write a module and include it another class definition

**Activity:**

Discuss the following with students using the whiteboard as necessary.
* What are modules? Why/when would you use them?

Demonstrate the following using a code-along.
* A module and a class that includes it.
