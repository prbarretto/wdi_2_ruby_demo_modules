module Climbing
  def climb
   puts "This #{self.class.name} is climbing"
  end
end